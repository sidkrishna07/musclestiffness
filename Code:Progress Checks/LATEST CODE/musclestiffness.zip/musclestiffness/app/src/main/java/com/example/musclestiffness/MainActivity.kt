package com.example.musclestiffness

import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.musclestiffness.ui.AppNavigation

import androidx.activity.viewModels

// BLE ViewModel

import com.example.musclestiffness.ble.BleViewModel

// Compose runtime
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.setValue

// Compose UI & layout
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding

import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp

// Theme & Model
import com.example.musclestiffness.ui.theme.MusclestiffnessTheme
import com.example.musclestiffness.utils.ModelHelper

import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.RoundedCornerShape

class MainActivity : ComponentActivity() {
    private val bleVm: BleViewModel by viewModels()
    companion object {
        private const val REQUEST_BLE_PERMISSIONS = 101
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check and request BLE permissions
        val neededPermissions = arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        val missing = neededPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing, REQUEST_BLE_PERMISSIONS)
        }

        // Load model from assets
        val modelLoaded = ModelHelper.loadModel(this)
        if (!modelLoaded) {
            Toast.makeText(this, "Failed to load model!", Toast.LENGTH_LONG).show()
            Log.e("MainActivity", "Model failed to load.")
        }

        setContent {
            val features by bleVm.features.collectAsState()

            MusclestiffnessTheme {
                AppNavigation(autoFeatures = features)
            }
        }
    }
}

@Composable
fun MuscleStiffnessUI(autoFeatures: FloatArray) {
    // Training ranges
    val featureMins = floatArrayOf(0.4145f, -13f, 165.33f, -0.000390f, 184.8f, 184.8f, 184.8f, 1.509f, 1.505f, 2.500f)
    val featureMaxs = floatArrayOf(0.7252f, 6.67f, 308.54f, 0.000442f, 219.6f, 219.6f, 219.6f, 2.719f, 3.764f, 9.692f)

    // Normalize helper
    fun normalizeInput(input: FloatArray) =
        input.mapIndexed { i, v ->
            val range = featureMaxs[i] - featureMins[i]
            if (range != 0f) (v - featureMins[i]) / range else 0f
        }.toFloatArray()

    // Shared predict helper
    var stiffnessProbability by remember { mutableStateOf<Float?>(null) }
    var explanationText    by remember { mutableStateOf("") }
    var isProcessing       by remember { mutableStateOf(false) }

    fun runPrediction(features: FloatArray) {
        val normalized = normalizeInput(features)
        val prediction = ModelHelper.predict(normalized)
        if (prediction != null) {
            val prob = prediction[0].coerceIn(0f, 1f)
            stiffnessProbability = prob
            explanationText = when {
                prob >= 0.7f -> "High risk – consider stretching, hydration, and rest."
                prob >= 0.4f -> "Moderate risk – light exercise and hydration might help."
                else         -> "Low risk – keep up your healthy routine!"
            }
        } else {
            explanationText = "Prediction error!"
            stiffnessProbability = null
        }
    }

    // Auto-run when BLE data arrives
    LaunchedEffect(autoFeatures) {
        isProcessing = true
        runPrediction(autoFeatures)
        isProcessing = false
    }

    // Manual fallback state
    var inputValues by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Muscle Stiffness Predictor", style = MaterialTheme.typography.headlineMedium)

        Spacer(Modifier.height(24.dp))

        // Manual entry
        OutlinedTextField(
            value = inputValues,
            onValueChange = { inputValues = it },
            label = { Text("Fallback sensor values (10 comma-separated)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {
                val parts = inputValues.split(",").mapNotNull { it.trim().toFloatOrNull() }
                if (parts.size == featureMins.size) {
                    isProcessing = true
                    runPrediction(parts.toFloatArray())
                    isProcessing = false
                } else {
                    explanationText = "Please enter exactly ${featureMins.size} values."
                    stiffnessProbability = null
                }
            },
            enabled = inputValues.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Check Stiffness")
        }

        Spacer(Modifier.height(16.dp))

        if (isProcessing) {
            CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
        }

        // Show result text
        if (explanationText.isNotEmpty()) {
            Text(explanationText, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(16.dp))
        }

        // Gauge & body map if we have a valid probability
        stiffnessProbability?.let { prob ->
            CircularGaugeCompose(prob)
            Spacer(Modifier.height(24.dp))
            BodyMap(prob)
        }
    }
}


/** Circular gauge remains the same. */
@Composable
fun CircularGaugeCompose(prob: Float) {
    val gaugeSize = 150.dp
    val percentage = (prob * 100).toInt()
    val gaugeColor = getColorForStiffness(prob)
    val strokePx = with(LocalDensity.current) { 20.dp.toPx() }

    Box(
        modifier = Modifier
            .size(gaugeSize)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(gaugeSize)) {
            val diameter = size.minDimension
            val radius = diameter / 2f
            val center = Offset(size.width / 2f, size.height / 2f)

            // Draw background arc
            drawArc(
                color = Color.LightGray,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                size = Size(diameter, diameter),
                style = Stroke(width = strokePx),
                topLeft = center - Offset(radius, radius)
            )

            // Draw foreground arc
            val sweep = 270f * prob
            drawArc(
                color = gaugeColor,
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                size = Size(diameter, diameter),
                style = Stroke(width = strokePx),
                topLeft = center - Offset(radius, radius)
            )
        }
        Text(
            text = "$percentage%",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = gaugeColor
        )
    }
}

/**
 * Replaces the list-based body parts overview with a single image-based approach.
 * Users can click on specific areas of the body to see stiffness details in a popup.
 */
@Composable
fun BodyMap(prob: Float) {
    // Stiffness for each region
    val regionStiffness = mapOf(
        "Neck" to prob * 0.25f,
        "Torso" to prob * 1.0f,
        "Left Arm" to prob * 0.6f,
        "Right Arm" to prob * 0.6f,
        "Left Leg" to prob * 0.8f,
        "Right Leg" to prob * 0.8f
    )

    // Track which region was clicked
    var selectedRegion by remember { mutableStateOf<String?>(null) }

    // Use a data class that stores *ratios* instead of dp for offset and size
    data class BodyRegionRatio(
        val name: String,
        val offsetXRatio: Float,
        val offsetYRatio: Float,
        val widthRatio: Float,
        val heightRatio: Float
    )

    // Define approximate region placements as a ratio of the container width/height
    // Tweak these numbers to match your silhouette
    val clickableRegions = listOf(
        BodyRegionRatio("Neck",     offsetXRatio = 0.47f, offsetYRatio = 0.06f, widthRatio = 0.10f, heightRatio = 0.10f),
        BodyRegionRatio("Torso",    offsetXRatio = 0.43f, offsetYRatio = 0.24f, widthRatio = 0.16f, heightRatio = 0.28f),
        BodyRegionRatio("Left Arm", offsetXRatio = 0.24f, offsetYRatio = 0.48f, widthRatio = 0.05f, heightRatio = 0.10f),
        BodyRegionRatio("Right Arm",offsetXRatio = 0.72f, offsetYRatio = 0.48f, widthRatio = 0.05f, heightRatio = 0.10f),
        BodyRegionRatio("Left Leg", offsetXRatio = 0.40f, offsetYRatio = 0.60f, widthRatio = 0.07f, heightRatio = 0.28f),
        BodyRegionRatio("Right Leg",offsetXRatio = 0.54f, offsetYRatio = 0.60f, widthRatio = 0.07f, heightRatio = 0.28f)
    )

    // Use BoxWithConstraints to get container dimensions
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(400.dp) // Adjust as you like
    ) {
        val containerWidth = maxWidth
        val containerHeight = maxHeight

        // Draw the base silhouette
        Image(
            painter = painterResource(id = R.drawable.body),
            contentDescription = "Body Diagram",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit
        )

        // Create clickable boxes for each region
        clickableRegions.forEach { region ->
            // Convert ratio to dp based on container size
            val offsetX = containerWidth * region.offsetXRatio
            val offsetY = containerHeight * region.offsetYRatio
            val boxWidth = containerWidth * region.widthRatio
            val boxHeight = containerHeight * region.heightRatio

            val stiffnessValue = regionStiffness[region.name] ?: 0f
            val overlayColor = getColorForStiffness(stiffnessValue).copy(alpha = 0.3f)

            Box(
                modifier = Modifier
                    .offset(x = offsetX, y = offsetY)
                    .size(width = boxWidth, height = boxHeight)
                    .background(color = overlayColor, shape = RoundedCornerShape(6.dp))
                    .clickable { selectedRegion = region.name }
            )
        }

        // Show a dialog when a region is clicked
        selectedRegion?.let { regionName ->
            val stiffnessValue = regionStiffness[regionName] ?: 0f
            val stiffnessPercent = (stiffnessValue * 100).toInt()

            AlertDialog(
                onDismissRequest = { selectedRegion = null },
                title = { Text(text = regionName) },
                text = {
                    Column {
                        Text("Stiffness: $stiffnessPercent%", style = MaterialTheme.typography.bodyLarge)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(getAdvice(regionName, stiffnessValue), color = Color.DarkGray)
                    }
                },
                confirmButton = {
                    Button(onClick = { selectedRegion = null }) {
                        Text("Close")
                    }
                }
            )
        }
    }
}


/** Data class for each body region’s placement on the image. */
data class BodyRegion(
    val name: String,
    val offsetX: Dp,
    val offsetY: Dp,
    val width: Dp,
    val height: Dp
)

/** Returns a color based on stiffness severity. */
fun getColorForStiffness(prob: Float): Color {
    return when {
        prob >= 0.7f -> Color.Red
        prob >= 0.4f -> Color(0xFFFFA500)
        else -> Color.Green
    }
}

/**
 * Returns advice for each region based on stiffness.
 * You can reuse or adapt your existing logic.
 */
fun getAdvice(region: String, stiffness: Float): String {
    val high = stiffness >= 0.7f
    val mid = stiffness in 0.4f..0.7f

    return when (region) {
        "Neck" -> when {
            high -> "High stiffness in neck: Do neck stretches, avoid prolonged looking down, and maintain proper posture."
            mid -> "Moderate stiffness in neck: Regular neck exercises and stretches can help."
            else -> "Low stiffness in neck: Keep up your healthy habits."
        }
        "Torso" -> when {
            high -> "High stiffness in torso: Incorporate back stretches and core strengthening exercises."
            mid -> "Moderate stiffness in torso: Consider light exercises to relieve tension."
            else -> "Low stiffness in torso: Continue your balanced activity."
        }
        "Left Arm", "Right Arm" -> when {
            high -> "High stiffness in arm: Do gentle arm stretches and avoid overexertion."
            mid -> "Moderate stiffness in arm: Light exercises may help ease tension."
            else -> "Low stiffness in arm: Maintain your regular movement."
        }
        "Left Leg", "Right Leg" -> when {
            high -> "High stiffness in leg: Incorporate leg stretches and avoid prolonged sitting."
            mid -> "Moderate stiffness in leg: Regular movement and stretching are beneficial."
            else -> "Low stiffness in leg: Your legs are doing well, keep active."
        }
        else -> "Maintain your healthy routine."
    }
}