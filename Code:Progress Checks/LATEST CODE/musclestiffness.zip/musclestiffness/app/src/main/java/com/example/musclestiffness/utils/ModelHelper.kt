package com.example.musclestiffness.utils

import android.content.Context
import android.util.Log
import org.pytorch.IValue
import org.pytorch.Module
import org.pytorch.Tensor
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object ModelHelper {
    private var model: Module? = null
    private const val TAG = "ModelHelper"

    fun loadModel(context: Context, modelName: String = "universal_model.pt"): Boolean {
        return try {
            val filePath = assetFilePath(context, modelName)
            model = Module.load(filePath)
            Log.d(TAG, "Model loaded successfully from: $filePath")
            true
        } catch (e: IOException) {
            Log.e(TAG, "Error loading model: ${e.message}")
            e.printStackTrace()
            false
        }
    }

    fun predict(inputArray: FloatArray): FloatArray? {
        if (model == null) {
            Log.e(TAG, "Model is not loaded. Call loadModel() first.")
            return null
        }
        return try {
            val inputTensor = Tensor.fromBlob(inputArray, longArrayOf(1, inputArray.size.toLong()))
            val outputTensor = model!!.forward(IValue.from(inputTensor)).toTensor()
            val rawOutput = outputTensor.dataAsFloatArray

            // Clamp the raw output to [0, 1] to ensure it's a valid probability
            val clampedOutput = rawOutput.map { it.coerceIn(0f, 1f) }.toFloatArray()
            Log.d(TAG, "Raw output: ${rawOutput.joinToString(", ")}")
            Log.d(TAG, "Clamped output: ${clampedOutput.joinToString(", ")}")

            clampedOutput
        } catch (e: Exception) {
            Log.e(TAG, "Prediction error: ${e.message}")
            e.printStackTrace()
            null
        }
    }

    private fun assetFilePath(context: Context, assetName: String): String {
        val file = File(context.filesDir, assetName)
        if (!file.exists()) {
            try {
                context.assets.open(assetName).use { inputStream ->
                    FileOutputStream(file).use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }
                Log.d(TAG, "Model file copied to: ${file.absolutePath}")
            } catch (e: IOException) {
                Log.e(TAG, "Error copying model file: ${e.message}")
                e.printStackTrace()
            }
        }
        return file.absolutePath
    }
}