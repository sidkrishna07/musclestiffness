@file:Suppress("unused", "DEPRECATION")
package com.example.musclestiffness.utils

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.annotation.SuppressLint
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import android.widget.Toast

@SuppressLint("MissingPermission")
@Suppress("unused", "DEPRECATION")
class BLEManager(
    private val context: Context,
    private val onFeatures: (FloatArray) -> Unit
) {
    private val bluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter = bluetoothManager.adapter
    private var bluetoothGatt: BluetoothGatt? = null

    // Scan timeout (optional)
    private val scanPeriod: Long = 10_000L

    // Scan callback
    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            result.device.name?.let { name ->
                if (name == DEVICE_NAME) {
                    stopScan()
                    connectToDevice(result.device)
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            // Handle scan failure if needed
        }
    }

    // GATT callback
    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                bluetoothGatt = gatt
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                bluetoothGatt = null
                // Optionally restart scanning
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val service: BluetoothGattService? = gatt.getService(SERVICE_UUID)
                service?.getCharacteristic(CHAR_UUID)?.let { characteristic ->
                    gatt.setCharacteristicNotification(characteristic, true)
                    // Enable notifications on the descriptor
                    characteristic.getDescriptor(CLIENT_CONFIG_UUID)?.let { descriptor ->
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        gatt.writeDescriptor(descriptor)
                    }
                }
            }
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            if (characteristic.uuid == CHAR_UUID) {
                val data: ByteArray = characteristic.value
                val buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
                val features = FloatArray(NUM_FEATURES) { buffer.float }
                onFeatures(features)
            }
        }
    }

    fun startScan() {
        try {
            Handler(Looper.getMainLooper()).postDelayed({ stopScan() }, scanPeriod)
            bluetoothAdapter.bluetoothLeScanner.startScan(scanCallback)
        } catch (e: SecurityException) {
            Toast.makeText(context, "Bluetooth scan permission required", Toast.LENGTH_LONG).show()
        }
    }

    fun stopScan() {
        bluetoothAdapter.bluetoothLeScanner.stopScan(scanCallback)
    }

    private fun connectToDevice(device: BluetoothDevice) {
        bluetoothGatt = device.connectGatt(context, false, gattCallback)
    }

    fun disconnect() {
        bluetoothGatt?.close()
        bluetoothGatt = null
    }

    companion object {
        private const val DEVICE_NAME = "MStiffSens"
        private val SERVICE_UUID: UUID =
            UUID.fromString("0000FFFF-0000-1000-8000-00805F9B34FB")
        private val CHAR_UUID: UUID =
            UUID.fromString("0000FFFE-0000-1000-8000-00805F9B34FB")
        private val CLIENT_CONFIG_UUID: UUID =
            UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")
        private const val NUM_FEATURES = 10
    }
}
