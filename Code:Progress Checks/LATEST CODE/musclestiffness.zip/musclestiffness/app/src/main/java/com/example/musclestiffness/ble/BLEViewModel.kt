package com.example.musclestiffness.ble

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.musclestiffness.utils.BLEManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class BleViewModel(application: Application) : AndroidViewModel(application) {
    private val _features = MutableStateFlow<FloatArray?>(null)
    val features: StateFlow<FloatArray?> = _features

    private val bleManager = BLEManager(application) { incoming ->
        viewModelScope.launch {
            _features.value = incoming
        }
    }

    init {
        bleManager.startScan()
    }

    override fun onCleared() {
        bleManager.disconnect()
        super.onCleared()
    }
}