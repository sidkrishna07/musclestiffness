package com.example.musclestiffness

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.musclestiffness.ui.theme.MusclestiffnessTheme
import com.example.musclestiffness.utils.ModelHelper
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import com.example.musclestiffness.ui.AppNavigation


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Load model from assets
        val modelLoaded = ModelHelper.loadModel(this)
        if (!modelLoaded) {
            Toast.makeText(this, "Failed to load model!", Toast.LENGTH_LONG).show()
            Log.e("MainActivity", "Model failed to load.")
        }

        setContent {
            MusclestiffnessTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    // Show the intro flow first, then jump into your existing MuscleStiffnessUI
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun MuscleStiffnessUI() {
    // These are your training min/max values from Python
    val featureMins = floatArrayOf(
        0.4145f, -13.0f, 165.33f, -0.000390f,
        184.8f, 184.8f, 184.8f, 1.509f, 1.505f, 2.500f
    )
    val featureMaxs = floatArrayOf(
        0.7252f, 6.67f, 308.54f, 0.000442f,
        219.6f, 219.6f, 219.6f, 2.719f, 3.764f, 9.692f
    )

    // Simple normalization helper
    fun normalizeInput(input: FloatArray, mins: FloatArray, maxs: FloatArray): FloatArray {
        return input.mapIndexed { i, v ->
            val range = maxs[i] - mins[i]
            if (range != 0f) (v - mins[i]) / range else v
        }.toFloatArray()
    }

    var inputValues by remember { mutableStateOf("0.57, -3.17, 236.94, 0.000026, 202.2, 202.2, 202.2, 2.114, 2.635, 6.096") }
    var stiffnessProbability by remember { mutableStateOf<Float?>(null) }
    var resultText by remember { mutableStateOf("") }
    var explanationText by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(brush = Brush.verticalGradient(colors = listOf(Color(0xFFFAFAFA), Color(0xFFE0E0E0))))
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Muscle Stiffness Predictor",
            style = MaterialTheme.typography.headlineMedium.copy(fontSize = 26.sp, fontWeight = FontWeight.Bold),
            color = Color(0xFF333333)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Enter 10 comma-separated raw sensor values:", style = MaterialTheme.typography.bodyLarge)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = inputValues,
                    onValueChange = { inputValues = it },
                    label = { Text("Sensor Values") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                isProcessing = true
                val parsedFloats = inputValues.split(",").mapNotNull { it.trim().toFloatOrNull() }
                val inputArray = parsedFloats.toFloatArray()
                if (inputArray.size == 10) {
                    val normalized = normalizeInput(inputArray, featureMins, featureMaxs)
                    val prediction = ModelHelper.predict(normalized)
                    if (prediction != null) {
                        val raw = prediction.firstOrNull() ?: 0f
                        val prob = raw.coerceIn(0f, 1f)
                        stiffnessProbability = prob
                        val pct = prob * 100f
                        resultText = "Probability of Muscle Stiffness: ${"%.2f".format(pct)}%"
                        explanationText = when {
                            prob >= 0.7f -> "High risk – consider stretching, hydration, and rest."
                            prob >= 0.4f -> "Moderate risk – light exercise and hydration might help."
                            else -> "Low risk – keep up your healthy routine!"
                        }
                        Log.d("MuscleStiffnessUI", "Raw=$raw, Clamped=$prob")
                    } else {
                        resultText = "Error in prediction!"
                        explanationText = "Something went wrong. Please try again."
                        stiffnessProbability = null
                        Log.e("MuscleStiffnessUI", "Prediction returned null.")
                    }
                } else {
                    resultText = "⚠️ Invalid Input!"
                    explanationText = "Please enter exactly 10 numerical values."
                    stiffnessProbability = null
                    Log.e("MuscleStiffnessUI", "Invalid input size: ${inputArray.size}")
                }
                isProcessing = false
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isProcessing,
            shape = RoundedCornerShape(8.dp)
        ) {
            if (isProcessing) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp))
            } else {
                Text("Check Stiffness", fontSize = 16.sp)
            }
        }
        Spacer(modifier = Modifier.height(20.dp))
        if (resultText.isNotEmpty()) {
            Text(
                text = resultText,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = when {
                    stiffnessProbability == null -> Color.Black
                    stiffnessProbability!! >= 0.7f -> Color.Red
                    stiffnessProbability!! >= 0.4f -> Color(0xFFFFA500)
                    else -> Color.Green
                }
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(explanationText, style = MaterialTheme.typography.bodyLarge, color = Color.DarkGray)
            Spacer(modifier = Modifier.height(20.dp))
            stiffnessProbability?.let { prob ->
                CircularGaugeCompose(prob)
                Spacer(modifier = Modifier.height(24.dp))
                BodyPartsOverview(prob)
            }
        }
    }
}

@Composable
fun CircularGaugeCompose(prob: Float) {
    val gaugeSize = 150.dp
    val percentage = (prob * 100).toInt()
    val gaugeColor = when {
        prob >= 0.7f -> Color.Red
        prob >= 0.4f -> Color(0xFFFFA500)
        else -> Color.Green
    }
    val strokePx = with(LocalDensity.current) { 20.dp.toPx() }
    Box(
        modifier = Modifier
            .size(gaugeSize)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(gaugeSize)) {
            val diameter = size.minDimension
            val radius = diameter / 2f
            val center = Offset(size.width / 2f, size.height / 2f)

            // Draw background arc
            drawArc(
                color = Color.LightGray,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                size = Size(diameter, diameter),
                style = Stroke(width = strokePx),
                topLeft = center - Offset(radius, radius)
            )

            // Draw foreground arc
            val sweep = 270f * prob
            drawArc(
                color = gaugeColor,
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                size = Size(diameter, diameter),
                style = Stroke(width = strokePx),
                topLeft = center - Offset(radius, radius)
            )
        }
        Text(
            text = "$percentage%",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = gaugeColor
        )
    }
}

@Composable
fun BodyPartsOverview(prob: Float) {
    val regionStiffness = mapOf(
        "Head" to prob * 0.2f,
        "Neck" to prob * 0.25f,
        "Torso" to prob * 1.0f,
        "Left Arm" to prob * 0.6f,
        "Right Arm" to prob * 0.6f,
        "Left Leg" to prob * 0.8f,
        "Right Leg" to prob * 0.8f
    )
    var showDialogFor by remember { mutableStateOf<String?>(null) }
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Body Part Details",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(vertical = 8.dp)
        )
        regionStiffness.forEach { (region, value) ->
            val pct = (value * 100).toInt()
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { showDialogFor = region },
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Using a placeholder image; replace with your custom images if available.
                        Image(
                            painter = painterResource(id = getImageForRegion(region)),
                            contentDescription = region,
                            modifier = Modifier.size(40.dp),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = region,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f)
                        )
                        LinearProgressIndicator(
                            progress = value.coerceIn(0f, 1f),
                            modifier = Modifier
                                .width(100.dp)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = when {
                                value >= 0.7f -> Color.Red
                                value >= 0.4f -> Color(0xFFFFA500)
                                else -> Color.Green
                            },
                            trackColor = Color.LightGray
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("$pct%")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = getAdvice(region, value),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.DarkGray
                    )
                }
            }
        }
    }
    showDialogFor?.let { region ->
        AlertDialog(
            onDismissRequest = { showDialogFor = null },
            title = { Text(region) },
            text = {
                val stiffnessValue = regionStiffness[region] ?: 0f
                val pct = (stiffnessValue * 100).toInt()
                Column {
                    Image(
                        painter = painterResource(id = getImageForRegion(region)),
                        contentDescription = region,
                        modifier = Modifier.size(80.dp),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Muscle Stiffness: $pct%")
                    Spacer(modifier = Modifier.height(8.dp))
                    Slider(
                        value = stiffnessValue,
                        onValueChange = {},
                        enabled = false,
                        modifier = Modifier.fillMaxWidth(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color.Transparent,
                            activeTrackColor = when {
                                stiffnessValue >= 0.7f -> Color.Red
                                stiffnessValue >= 0.4f -> Color(0xFFFFA500)
                                else -> Color.Green
                            },
                            inactiveTrackColor = Color.LightGray
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(getAdvice(region, stiffnessValue), style = MaterialTheme.typography.bodyMedium)
                }
            },
            confirmButton = {
                Button(onClick = { showDialogFor = null }) {
                    Text("Close")
                }
            }
        )
    }
}

fun getAdvice(region: String, stiffness: Float): String {
    return when (region) {
        "Head" -> {
            when {
                stiffness >= 0.7f -> "High stiffness in head: Perform gentle head movements and avoid sudden motions."
                stiffness >= 0.4f -> "Moderate stiffness in head: Regular stretching and relaxation exercises recommended."
                else -> "Low stiffness: Maintain your routine."
            }
        }
        "Neck" -> {
            when {
                stiffness >= 0.7f -> "High stiffness in neck: Do neck stretches, avoid prolonged looking down and maintain proper posture."
                stiffness >= 0.4f -> "Moderate stiffness in neck: Regular neck exercises and stretches can help."
                else -> "Low stiffness: Keep up your healthy habits."
            }
        }
        "Torso" -> {
            when {
                stiffness >= 0.7f -> "High stiffness in torso: Incorporate back stretches and core strengthening exercises."
                stiffness >= 0.4f -> "Moderate stiffness in torso: Consider light exercises to relieve tension."
                else -> "Low stiffness: Continue your balanced activity."
            }
        }
        "Left Arm", "Right Arm" -> {
            when {
                stiffness >= 0.7f -> "High stiffness in arm: Do gentle arm stretches and avoid overexertion."
                stiffness >= 0.4f -> "Moderate stiffness in arm: Light exercises may help ease tension."
                else -> "Low stiffness: Maintain your regular movement."
            }
        }
        "Left Leg", "Right Leg" -> {
            when {
                stiffness >= 0.7f -> "High stiffness in leg: Incorporate leg stretches and avoid prolonged sitting."
                stiffness >= 0.4f -> "Moderate stiffness in leg: Regular movement and stretching are beneficial."
                else -> "Low stiffness: Your legs are doing well, keep active."
            }
        }
        else -> "Maintain your healthy routine."
    }
}

fun getImageForRegion(region: String): Int {
    return when (region) {
        "Head" -> R.drawable.head
        "Neck" -> R.drawable.neck
        "Torso" -> R.drawable.torso
        "Left Arm" -> R.drawable.leftarm
        "Right Arm" -> R.drawable.rightarm
        "Left Leg" -> R.drawable.leftleg
        "Right Leg" -> R.drawable.rightleg
        else -> R.drawable.ic_launcher_foreground
    }
}

