package com.example.musclestiffness.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.musclestiffness.MuscleStiffnessUI

@Composable
fun AppNavigation() {
    var currentScreen by remember { mutableStateOf(0) }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when (currentScreen) {
            0 -> WelcomeScreen(onNext = { currentScreen++ })
            1 -> ConnectDeviceScreen(onNext = { currentScreen++ })
            2 -> ReadyScreen(onNext = { currentScreen++ })
            else -> MuscleStiffnessUI()
        }
    }
}

@Composable
fun WelcomeScreen(onNext: () -> Unit) {
    ScreenTemplate(
        title = "Welcome to the Muscle Stiffness App",
        subtitle = "Track your progress and improve your muscle health",
        buttonText = "Get Started",
        onNext = onNext
    )
}

@Composable
fun ConnectDeviceScreen(onNext: () -> Unit) {
    val context = LocalContext.current
    // When the button is clicked, launch the system Bluetooth settings
    ScreenTemplate(
        title = "Connect Your Device",
        subtitle = "Tap to search for available Bluetooth devices",
        buttonText = "Search Devices",
        onNext = {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            context.startActivity(intent)
            onNext()
        }
    )
}

@Composable
fun ReadyScreen(onNext: () -> Unit) {
    ScreenTemplate(
        title = "Device Connected",
        subtitle = "Your device is ready. Let’s get moving!",
        buttonText = "Continue",
        onNext = onNext
    )
}

@Composable
fun ScreenTemplate(
    title: String,
    subtitle: String = "",
    buttonText: String,
    onNext: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF4A90E2), // Vibrant blue
                        Color(0xFF50E3C2)  // Refreshing teal
                    )
                )
            )
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .align(Alignment.Center)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )
                if (subtitle.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = onNext,
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text(text = buttonText, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}
