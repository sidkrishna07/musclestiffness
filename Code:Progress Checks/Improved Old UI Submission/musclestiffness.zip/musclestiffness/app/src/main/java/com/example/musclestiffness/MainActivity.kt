package com.example.musclestiffness

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.musclestiffness.ui.theme.MusclestiffnessTheme
import com.example.musclestiffness.utils.ModelHelper
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Load the model from assets
        val modelLoaded = ModelHelper.loadModel(this)
        if (!modelLoaded) {
            Toast.makeText(this, "Failed to load model!", Toast.LENGTH_LONG).show()
            Log.e("MainActivity", "Model failed to load.")
        }

        setContent {
            MusclestiffnessTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF0F0F0)
                ) {
                    MuscleStiffnessUI()
                }
            }
        }
    }
}

@Composable
fun MuscleStiffnessUI() {
    // These are your training min/max from the Python scaler
    val featureMins = floatArrayOf(
        0.4145f, -13.0f, 165.33f, -0.000390f,
        184.8f, 184.8f, 184.8f, 1.509f, 1.505f, 2.500f
    )
    val featureMaxs = floatArrayOf(
        0.7252f, 6.67f, 308.54f, 0.000442f,
        219.6f, 219.6f, 219.6f, 2.719f, 3.764f, 9.692f
    )

    // Normalize the raw input
    fun normalizeInput(input: FloatArray, mins: FloatArray, maxs: FloatArray): FloatArray {
        return input.mapIndexed { i, v ->
            val range = maxs[i] - mins[i]
            if (range != 0f) (v - mins[i]) / range else v
        }.toFloatArray()
    }

    // Basic radar chart info
    val metricShortNames = listOf("Corr","Lag","Amp","Decay","BW1","BW2","BW3","E12","E23","E13")
    val metricFullNames = listOf(
        "Correlation","Lag","Amplitude","Decay Variation","Bandwidth 1","Bandwidth 2","Bandwidth 3",
        "Energy Ratio 1-2","Energy Ratio 2-3","Energy Ratio 1-3"
    )
    val metricDescriptions = listOf(
        "Average correlation between sensor signals.",
        "Average lag time between sensor signals.",
        "Maximum amplitude observed.",
        "Variation in decay rate of the signal.",
        "Estimated bandwidth from sensor 1.",
        "Estimated bandwidth from sensor 2.",
        "Estimated bandwidth from sensor 3.",
        "Energy ratio between sensor 1 and 2.",
        "Energy ratio between sensor 2 and 3.",
        "Energy ratio between sensor 1 and 3."
    )

    // UI state
    var inputValues by remember { mutableStateOf("0.57, -3.17, 236.94, 0.000026, 202.2, 202.2, 202.2, 2.114, 2.635, 6.096") }
    var stiffnessProbability by remember { mutableStateOf<Float?>(null) }
    var resultText by remember { mutableStateOf("") }
    var explanationText by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }
    var sensorValues by remember { mutableStateOf<FloatArray?>(null) }
    var selectedMetricIndex by remember { mutableStateOf(-1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(Color.White)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Muscle Stiffness Predictor",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontSize = 24.sp, fontWeight = FontWeight.Bold
            ),
            color = Color(0xFF333333)
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Input Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Enter 10 comma-separated raw sensor values:",
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = inputValues,
                    onValueChange = { inputValues = it },
                    label = { Text("Sensor Values") },
                    placeholder = { Text("e.g. 0.57, -3.17, 236.94, ...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Prediction Button
        Button(
            onClick = {
                isProcessing = true
                // Parse user input
                val parsedFloats = inputValues
                    .split(",")
                    .mapNotNull { it.trim().toFloatOrNull() }
                val inputArray = parsedFloats.toFloatArray()

                if (inputArray.size == 10) {
                    sensorValues = inputArray
                    // Normalize
                    val normalizedInput = normalizeInput(inputArray, featureMins, featureMaxs)
                    // Predict
                    val prediction = ModelHelper.predict(normalizedInput)

                    if (prediction != null) {
                        // We'll treat the raw model output as the probability
                        val rawOutput = prediction.firstOrNull() ?: 0f
                        // but clamp it so it never goes above 1.0 or below 0.0
                        val clampedProb = rawOutput.coerceIn(0f, 1f)

                        stiffnessProbability = clampedProb
                        val percentage = clampedProb * 100f
                        resultText = "Probability of Muscle Stiffness: ${"%.2f".format(percentage)}%"
                        explanationText = when {
                            clampedProb >= 0.7f -> "High risk of muscle stiffness. Consider stretching, hydration, and rest."
                            clampedProb >= 0.4f -> "Moderate risk. Light exercise and hydration might help."
                            else -> "Low risk of stiffness. Keep maintaining a healthy routine!"
                        }
                        Log.d("MuscleStiffnessUI", "Raw = $rawOutput, Clamped = $clampedProb")
                    } else {
                        resultText = "Error"
                        explanationText = "Something went wrong. Try again."
                        stiffnessProbability = null
                        Log.e("MuscleStiffnessUI", "Prediction returned null.")
                    }
                } else {
                    resultText = "⚠️ Invalid Input!"
                    explanationText = "Please enter exactly 10 numerical values separated by commas."
                    sensorValues = null
                    stiffnessProbability = null
                    Log.e("MuscleStiffnessUI", "Invalid input size: ${inputArray.size}")
                }
                isProcessing = false
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isProcessing
        ) {
            if (isProcessing) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp))
            } else {
                Text("Check Stiffness", fontSize = 16.sp)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Show results if available
        if (resultText.isNotEmpty()) {
            Text(
                text = resultText,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = when {
                    stiffnessProbability == null -> Color.Black
                    stiffnessProbability!! >= 0.7f -> Color.Red
                    stiffnessProbability!! >= 0.4f -> Color(0xFFFFA500)
                    else -> Color.Green
                }
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = explanationText,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.DarkGray
            )
            Spacer(modifier = Modifier.height(24.dp))

            stiffnessProbability?.let { prob ->
                SemiCircularGauge(prob)
            }
            Spacer(modifier = Modifier.height(24.dp))

            HorizontalDivider(color = Color.Gray, thickness = 1.dp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Key Indicators",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text("Tap a region in the chart for more info.", color = Color.Gray)
            Spacer(modifier = Modifier.height(16.dp))

            // Radar chart
            sensorValues?.let { rawVals ->
                val normalizedVals = rawVals.mapIndexed { i, v ->
                    val range = featureMaxs[i] - featureMins[i]
                    if (range != 0f) (v - featureMins[i]) / range else 0f
                }
                RadarChartNoOffset(
                    normalizedValues = normalizedVals,
                    metricShortNames = metricShortNames
                ) { index -> selectedMetricIndex = index }

                Spacer(modifier = Modifier.height(16.dp))
                if (selectedMetricIndex in metricShortNames.indices) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Text(
                            text = "${metricFullNames[selectedMetricIndex]}: " +
                                    metricDescriptions[selectedMetricIndex],
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SemiCircularGauge(prob: Float) {
    // prob is in [0..1], so 100% is max
    val gaugeSize = 200.dp
    Box(
        modifier = Modifier
            .size(gaugeSize)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(gaugeSize)) {
            val widthPx = size.width
            val heightPx = size.height
            val strokeWidth = 20f

            val left = strokeWidth
            val top = strokeWidth
            val right = widthPx - strokeWidth
            val bottom = heightPx * 2f - strokeWidth

            // Background arc
            drawArc(
                color = Color.LightGray,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = androidx.compose.ui.geometry.Offset(left, top),
                size = androidx.compose.ui.geometry.Size(right - left, bottom - top),
                style = Stroke(width = strokeWidth)
            )

            // Progress arc
            val progressColor = when {
                prob >= 0.7f -> Color.Red
                prob >= 0.4f -> Color(0xFFFFA500)
                else -> Color.Green
            }
            val sweep = 180f * prob
            drawArc(
                color = progressColor,
                startAngle = 180f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = androidx.compose.ui.geometry.Offset(left, top),
                size = androidx.compose.ui.geometry.Size(right - left, bottom - top),
                style = Stroke(width = strokeWidth)
            )
        }
        Text(
            text = "${(prob * 100).toInt()}%",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
fun RadarChartNoOffset(
    normalizedValues: List<Float>,
    metricShortNames: List<String>,
    onTapMetric: (Int) -> Unit
) {
    val itemCount = normalizedValues.size
    val chartSize = 300.dp

    Box(
        modifier = Modifier
            .size(chartSize)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .size(chartSize)
                .pointerInput(Unit) {
                    detectTapGestures { tapPos ->
                        val widthPx = size.width
                        val heightPx = size.height
                        val centerX = widthPx / 2f
                        val centerY = heightPx / 2f
                        val dx = tapPos.x - centerX
                        val dy = tapPos.y - centerY
                        val angle = atan2(dy, dx)
                        val angle2Pi = if (angle < 0) angle + 2f * PI.toFloat() else angle
                        val sliceAngle = (2f * PI.toFloat()) / itemCount
                        val tappedIndex = (angle2Pi / sliceAngle).toInt() % itemCount
                        onTapMetric(tappedIndex)
                    }
                }
        ) {
            val widthPx = size.width
            val heightPx = size.height
            val centerX = widthPx / 2f
            val centerY = heightPx / 2f
            val radius = min(widthPx, heightPx) / 2f * 0.8f

            // 4 radial rings
            val ringCount = 4
            for (r in 1..ringCount) {
                val ringRadius = radius * (r / ringCount.toFloat())
                drawArc(
                    color = Color.LightGray.copy(alpha = 0.3f),
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = androidx.compose.ui.geometry.Offset(centerX - ringRadius, centerY - ringRadius),
                    size = androidx.compose.ui.geometry.Size(ringRadius * 2, ringRadius * 2),
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            // spokes
            for (i in 0 until itemCount) {
                val angleRad = (2f * PI.toFloat() / itemCount) * i
                val x = centerX + radius * cos(angleRad)
                val y = centerY + radius * sin(angleRad)

                val linePath = Path().apply {
                    moveTo(centerX, centerY)
                    lineTo(x, y)
                }
                drawPath(
                    path = linePath,
                    color = Color.LightGray,
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            // polygon path
            val polygonPath = Path()
            normalizedValues.forEachIndexed { i, value ->
                val angleRad = (2f * PI.toFloat() / itemCount) * i
                val r = radius * value
                val px = centerX + r * cos(angleRad)
                val py = centerY + r * sin(angleRad)
                if (i == 0) polygonPath.moveTo(px, py) else polygonPath.lineTo(px, py)
            }
            polygonPath.close()

            // fill
            drawPath(
                path = polygonPath,
                color = Color(0xFF4CAF50).copy(alpha = 0.3f)
            )
            // outline
            drawPath(
                path = polygonPath,
                color = Color(0xFF4CAF50),
                style = Stroke(width = 2.dp.toPx())
            )

            // short labels
            normalizedValues.forEachIndexed { i, _ ->
                val angleRad = (2f * PI.toFloat() / itemCount) * i
                val labelRadius = radius + 18.dp.toPx()
                val lx = centerX + labelRadius * cos(angleRad)
                val ly = centerY + labelRadius * sin(angleRad)

                drawIntoCanvas { canvas ->
                    val paint = android.graphics.Paint().apply {
                        textSize = 30f
                        color = android.graphics.Color.BLACK
                        textAlign = android.graphics.Paint.Align.CENTER
                    }
                    canvas.nativeCanvas.drawText(
                        metricShortNames[i],
                        lx,
                        ly,
                        paint
                    )
                }
            }
        }
    }
}
