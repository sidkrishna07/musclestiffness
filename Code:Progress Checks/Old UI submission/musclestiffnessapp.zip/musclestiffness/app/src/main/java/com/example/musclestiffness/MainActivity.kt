package com.example.musclestiffness

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.musclestiffness.ui.theme.MusclestiffnessTheme
import com.example.musclestiffness.utils.ModelHelper
import kotlin.math.exp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Load the model from assets
        val modelLoaded = ModelHelper.loadModel(this)
        if (!modelLoaded) {
            Toast.makeText(this, "Failed to load model!", Toast.LENGTH_LONG).show()
            Log.e("MainActivity", "Model failed to load.")
        }

        setContent {
            MusclestiffnessTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF0F0F0)
                ) {
                    MuscleStiffnessUI()
                }
            }
        }
    }
}

@Composable
fun MuscleStiffnessUI() {
    // These are the training min/max values extracted from your Python scaler.
    val featureMins = floatArrayOf(0.4145f, -13.0f, 165.33f, -0.000390f, 184.8f, 184.8f, 184.8f, 1.509f, 1.505f, 2.500f)
    val featureMaxs = floatArrayOf(0.7252f, 6.67f, 308.54f, 0.000442f, 219.6f, 219.6f, 219.6f, 2.719f, 3.764f, 9.692f)

    // Function to normalize raw input using the training min/max values.
    fun normalizeInput(input: FloatArray, mins: FloatArray, maxs: FloatArray): FloatArray {
        val normalized = FloatArray(input.size)
        for (i in input.indices) {
            val range = maxs[i] - mins[i]
            normalized[i] = if (range != 0f) {
                (input[i] - mins[i]) / range
            } else {
                input[i]
            }
        }
        return normalized
    }

    // Default raw sensor values – these are in the same scale as your training data.
    // (These are the midpoints of each feature's raw range.)
    var inputValues by remember { mutableStateOf("0.57, -3.17, 236.94, 0.000026, 202.2, 202.2, 202.2, 2.114, 2.635, 6.096") }
    var resultText by remember { mutableStateOf("") }
    var explanationText by remember { mutableStateOf("") }
    var resultColor by remember { mutableStateOf(Color.Black) }
    var isProcessing by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .background(Color.White),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Muscle Stiffness Predictor",
            style = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold),
            color = Color(0xFF333333)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Enter 10 comma-separated raw sensor values:")

        BasicTextField(
            value = inputValues,
            onValueChange = { inputValues = it },
            keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { }),
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.LightGray)
                .padding(8.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                isProcessing = true
                val inputArray = inputValues.split(",")
                    .mapNotNull { it.trim().toFloatOrNull() }
                    .toFloatArray()
                if (inputArray.size == 10) {
                    // Normalize the raw inputs using the training min and max.
                    val normalizedInput = normalizeInput(inputArray, featureMins, featureMaxs)
                    val prediction = ModelHelper.predict(normalizedInput)
                    if (prediction != null) {
                        // The model's raw output is still off.
                        // Here we subtract an offset and apply a Sigmoid, then invert the result.
                        // For mid-range inputs the raw output is ~22.38.
                        val rawOutput = prediction.firstOrNull() ?: 0.0f
                        val offset = 22.38f  // determined from testing mid-range input
                        val adjustedOutput = rawOutput - offset
                        // Apply Sigmoid.
                        val sigmoidOutput = 1f / (1f + exp(-adjustedOutput.toDouble())).toFloat()
                        // Invert the probability so that lower raw values (min) yield low risk.
                        val stiffnessProbability = 1f - sigmoidOutput
                        val percentage = stiffnessProbability * 100

                        resultText = "Probability of Muscle Stiffness: ${"%.2f".format(percentage)}%"
                        explanationText = when {
                            stiffnessProbability >= 0.7 -> "High risk of muscle stiffness. Consider stretching, hydration, and rest."
                            stiffnessProbability >= 0.4 -> "Moderate risk. Light exercise and hydration might help."
                            else -> "Low risk of stiffness. Keep maintaining a healthy routine!"
                        }
                        resultColor = when {
                            stiffnessProbability >= 0.7 -> Color.Red
                            stiffnessProbability >= 0.4 -> Color(0xFFFFA500)
                            else -> Color.Green
                        }
                        Log.d(
                            "MuscleStiffnessUI",
                            "Raw output: $rawOutput, Normalized input: ${normalizedInput.toList()}, Adjusted output: $adjustedOutput, Sigmoid: $sigmoidOutput, Final: $stiffnessProbability"
                        )
                    } else {
                        resultText = "Error"
                        explanationText = "Something went wrong. Try again."
                        resultColor = Color.Gray
                        Log.e("MuscleStiffnessUI", "Prediction returned null.")
                    }
                } else {
                    resultText = "⚠️ Invalid Input!"
                    explanationText = "Please enter exactly 10 numerical values separated by commas."
                    resultColor = Color.Red
                    Log.e("MuscleStiffnessUI", "Invalid input size: ${inputArray.size}")
                }
                isProcessing = false
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isProcessing
        ) {
            if (isProcessing) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp))
            } else {
                Text("Check Stiffness", fontSize = 16.sp)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        if (resultText.isNotEmpty()) {
            Text(
                text = resultText,
                fontSize = 22.sp,
                color = resultColor,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = explanationText, fontSize = 16.sp, color = Color.DarkGray)
        }
    }
}
